# NAJI — Liquid Crystal API

## Publish
1. Upload this folder to a Node.js host.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Run `npm start`.
5. Open the site and tap **Generate API** only if you want an API key.

The normal website works without generating a key.

## API
- `POST /api/generate-key` — creates a new key and stores it server-side in `.env`.
- `GET /api/sound` — public demo/device endpoint used by the normal site.
- `GET /api/sound/secure` — protected endpoint; send `Authorization: Bearer YOUR_KEY`.

Important: `.env` must never be committed to a public repository. For serverless hosts where the filesystem is read-only, use the host's environment-variable/secret manager instead of writing `.env` at runtime.


## ESP32 Sound Sensor
A ready-to-upload Arduino sketch is included at `esp32/sound_sensor.ino`. It reads a digital sound sensor on GPIO 27 and reports the state at 115200 baud. See `esp32/README.md` for wiring.
